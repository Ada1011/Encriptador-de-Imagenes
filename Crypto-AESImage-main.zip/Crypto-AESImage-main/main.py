from GUI import GUI

if __name__ == "__main__":
    gui = GUI()
    gui.run()
